package assignment;

import java.util.Scanner;

public class q14 {
    static int a[];
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
		int arr[] = new int[sc.nextInt()];
        System.out.println("enter elements");
        for (int i = 0; i < arr.length; i++) {
            arr[i]=sc.nextInt(); 
        }
        int count=0;
        for (int i : arr) {
            for (int j : arr) {
                if(i==j) {j=Integer.MAX_VALUE;
                    count++;}
            }
            System.out.printf("count of %d is %d %n", i, count);
            count=0;
        }
        
    }
}
