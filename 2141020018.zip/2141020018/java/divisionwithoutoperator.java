public class divisionwithoutoperator {
    public static void main(String[] args) {
        int a=(7);
        int b=(3);
        int min=Math.min(a, b);
        int max=Math.max(a, b);int c=0;
        while(max>=min){
            c++;
            max-=min;
        }
        System.out.println(c);
        divisionwithoutoperator ob=new divisionwithoutoperator();
        System.out.println(ob instanceof divisionwithoutoperator);
    //     System.out.println(b instanceof int);
    //     System.out.println(divisionwithoutoperator instanceof ob);
    // }
}
}
