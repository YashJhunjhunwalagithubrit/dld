public class DemoArrayMulti {
    public static void main(String[] args) {
        String[][] salName = { { "Mr. ", "Mrs. ", "Ms. " }, { "Alan", "Janice" } };
        for (int i = 0; i < salName.length; i++) {
            for (int j = 0; j < salName[i].length; j++) {
                char a[]=salName[i][j].toCharArray();
                System.out.println(a[0]);
            }
        }
        
    }
}
