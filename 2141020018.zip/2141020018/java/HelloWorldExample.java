import java.time.Year;

public class HelloWorldExample {
public static void main(String args[]) {
		int b=20;
		Integer c=Integer.valueOf(b);
		int d=Integer.valueOf(c);
		Year y=Year.of(2022);
		System.out.println(c.getClass().getName());
		String s=Double.toString(Math.pow(2, 31));
		System.out.println(s);
		System.out.println(Integer.MAX_VALUE+" "+Integer.MIN_VALUE);

}
}