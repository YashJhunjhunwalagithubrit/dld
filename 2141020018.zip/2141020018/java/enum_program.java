enum weekdays {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY,
    THURSDAY, FRIDAY, SATURDAY
}

public class enum_program {
    public static void main(String[] args) {
        for (weekdays weekdays2 : weekdays.values()) {
            System.out.println(weekdays2+" "+weekdays2.ordinal());
        }
        String s=Integer.toString(22);
        weekdays w=weekdays.MONDAY;
        System.out.println(weekdays.valueOf(w.toString()).ordinal());
        System.out.println(w.ordinal());                   
        long a=Long.MAX_VALUE;
        int b=(int) a;
        int c=256;
        byte d=(byte)c;
        System.out.println(d);

    }
}
