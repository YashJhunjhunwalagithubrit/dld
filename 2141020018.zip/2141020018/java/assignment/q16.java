package assignment;

/*package whatever //do not write package name here */

import java.io.*;
import java.util.Scanner;

class q16 {


// Function to rotate array
static void Rotate(int arr[], int d, int n)
{
	// Storing rotated version of array
	int temp[] = new int[n];

	// Keeping track of the current index
	// of temp[]
	int k = 0;

	// Storing the n - d elements of
	// array arr[] to the front of temp[]
	for (int i = d; i < n; i++) {
		temp[k] = arr[i];
		k++;
	}

	// Storing the first d elements of array arr[]
	// into temp
	for (int i = 0; i < d; i++) {
		temp[k] = arr[i];
		k++;
	}

	// Copying the elements of temp[] in arr[]
	// to get the final rotated array
	for (int i = 0; i < n; i++) {
		arr[i] = temp[i];
	}
}

// Function to print elements of array
static void PrintTheArray(int arr[], int n)
{
	for (int i = 0; i < n; i++) {
		System.out.print(arr[i]+" ");
	}
}
	public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
		int arr[] = new int[sc.nextInt()];
        System.out.println("enter rotation");
		int d = sc.nextInt();
		int N = arr.length;
        if(d>N){
            System.out.println("rotation not possible");
            System.exit(0);
        }
        System.out.println("enter elements");
        for (int i = 0; i < arr.length; i++) {
            arr[i]=sc.nextInt();
        }
		// Function calling
		Rotate(arr, d, N);
		PrintTheArray(arr, N);
	}
}

// This code is contributed by ishankhandelwals.

