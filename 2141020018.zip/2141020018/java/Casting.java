import java.util.ArrayList;
import java.util.List;
public class Casting {
    public static void main(String args[]) {
        List<Integer> mylist = new ArrayList<Integer>();
        mylist.add(10);
        mylist.add(20);
        for (Integer integer : mylist) {
            
            System.out.println(integer);
        }
    }
}