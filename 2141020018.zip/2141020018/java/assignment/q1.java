package assignment;

import java.util.Scanner;

/**
 * q1
 */
public class q1 {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        // System.out.println("Enter number");
        // int n=sc.nextInt();
        // System.out.println("No of bits: "+count(n));
        System.out.println(~(5));
        int n=10;
    }
    public static int count(int n) {
        String s="";
        while(n>0){
            s=s+Integer.toString(n%2);
            n>>=1;
        }
        int length=s.length();
        return length;
    }
}