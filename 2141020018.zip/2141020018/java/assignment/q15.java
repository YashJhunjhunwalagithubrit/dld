package assignment;

import java.util.Scanner;

public class q15 {
    static boolean isPrime(int n)
    {
        // Corner case
        if (n <= 1)
            return false;
 
        // Check from 2 to n-1
        for (int i = 2; i < n; i++)
            if (n % i == 0)
                return false;
 
        return true;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size");
		int arr[] = new int[sc.nextInt()];
        int count=0;
        System.out.println("enter elements");
        for (int i = 0; i < arr.length; i++) {
            arr[i]=sc.nextInt();
            boolean b=isPrime(arr[i]);
            if(b) count++;
        }
        System.out.println("primes"+count);

    }
}
