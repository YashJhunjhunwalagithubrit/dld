package assign;
class DemoEncap {
    private int ssnValue;
    private int employeeAge;
    private String employeeName;

    // We will employ get and set methods to use the class objects
    public int getEmployeeSSN() {
        return ssnValue;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public int getEmployeeAge() {
        return employeeAge;
    }

    public void setEmployeeAge(int newValue) {
        employeeAge = newValue;
    }

    public void setEmployeeName(String newValue) {
        employeeName = newValue;
    }

    public void setEmployeeSSN(int newValue) {
        ssnValue = newValue;
    }
    public String toString(){
        return getEmployeeName()+" "+getEmployeeAge();
    }
    public boolean equals(Object a, Object b){
        if(a instanceof DemoEncap && b instanceof DemoEncap){
            DemoEncap d=(DemoEncap)a;
            DemoEncap e=(DemoEncap)b;
            if(d.ssnValue==e.ssnValue && d.employeeAge==e.employeeAge && d.employeeName.compareToIgnoreCase(e.employeeName)==0)
             return true;
        }
        return false;
    }
}

public class TestEncapsulation {
    public static void main(String args[]) {
        DemoEncap obj = new DemoEncap();
        obj.setEmployeeName("Mark");
        obj.setEmployeeAge(30);
        obj.setEmployeeSSN(12345);
        DemoEncap obj1=new DemoEncap();
        obj1.setEmployeeName("Mark");
        obj1.setEmployeeAge(30);
        obj1.setEmployeeSSN(12345);
        TestEncapsulation t3=new TestEncapsulation();
        System.out.println("Employee Name is: " + obj.getEmployeeName());
        System.out.println("Employee SSN Code is: " + obj.getEmployeeSSN());
        System.out.println("Employee Age is: " + obj.getEmployeeAge());
        System.out.println(obj.toString());
        System.out.println(obj.equals(obj,obj));
    }
}