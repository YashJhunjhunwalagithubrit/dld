package assignment;

import java.lang.reflect.Array;
import java.util.Scanner;

public class Num {
    static int a[];
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of arrray");
        int n=sc.nextInt();
        a=new int[n];
        for (int i = 0; i < n; i++) {
            System.out.println("enter value");
            Array.set(a,i ,sc.nextInt());
        }
        a=reverse(a);
        for (int i : a) {
            System.out.println(i);
        }
    }
    public static int[] reverse(int a[]) {
        int a1[]=new int[a.length];
        for (int i = 0; i < a.length; i++) {
    
        }
        return a1;
    }
}
