enum CarTypes {
    Sport, Sedan, Hatchback, SUV, Mini, Hybrid
}

public class enum1 {
    CarTypes carTypes;

    public enum1(CarTypes carTypes) {
        this.carTypes = carTypes;
    }

    public void carFeatures() {
        switch (carTypes.ordinal()) {
            case 0:
                System.out.println("Stylish car with power");
                break;
            case 5:
                System.out.println("Economical as partially runs on battery power");
                break;
            case 2:
            case 3:
                System.out.println("Rear door swings upward to provide access to the cargo area");
                break;
            default:
                System.out.println("Just a car");
                break;
        }
    }

    public static void main(String[] args) {
        enum1 carOne = new enum1(CarTypes.Sport);
        carOne.carFeatures();
        enum1 carTwo = new enum1(CarTypes.Hatchback);
        carTwo.carFeatures();
        enum1 carThree = new enum1(CarTypes.Mini);
        carThree.carFeatures();
    }
}
