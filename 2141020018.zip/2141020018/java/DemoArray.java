public class DemoArray {
public static void main(String[] args) {
int[] oneArray;
// we initiate an integer array
oneArray = new int[5];
//We set up 5 memory locations for the array
oneArray[0] = 122;
oneArray[1] = 212;
oneArray[2] = 58;
oneArray[3] = 125;
oneArray[4] = 200;
//We store 5 separate integers in successive positions
System.out.println("The first element is: "+ oneArray[0]);
System.out.println("The second element is: "+ oneArray[1]);
System.out.println("The third element is: "+ oneArray[2]);
System.out.println("The fourth element is: "+ oneArray[3]);
System.out.println("The fifth element is: "+ oneArray[4]);
}
}