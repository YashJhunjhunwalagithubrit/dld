
class Dog implements Cloneable{
    int eyes, feet;
    public Object clone() throws CloneNotSupportedException{
        return super.clone();
        
    }
}

public class Main{
    
    public static void main(String[] args) throws CloneNotSupportedException{
        Dog d1=new Dog();
        d1.eyes=2;
        d1.feet=4;
        Dog d2=(Dog)d1.clone();
        System.out.println(d1.eyes+"\n"+d2.eyes);
        d2.eyes=3;
        System.out.println(d1.eyes+"\n"+d2.eyes);

    }
    
}
