public class CopyArrayExam {
static char[] copySource = { 'f', 'g', 'o', 'd', 'a', 'm', 'n' };
static char[] copyDest = {'a','b','c'};
public static void main(String args[]) {
System.arraycopy(copySource, 0, copyDest, 0, 1);

System.out.println(new String(copyDest));
}
}