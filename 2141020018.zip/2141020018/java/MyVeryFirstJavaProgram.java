public class MyVeryFirstJavaProgram {
    int firstnum;
    public static void main(String[] args) {
        // This code will present the message within the quotations ahead in the
        // terminal display window.
        System.out.println("First Java Program");
        {
            int firstnum=1;
            System.out.println("first number is " + firstnum);
        }
        int firstnum = 2;
        System.out.println("first number is now " + firstnum);
    }
}