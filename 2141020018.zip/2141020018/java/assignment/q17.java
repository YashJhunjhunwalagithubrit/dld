package assignment;

import java.util.Scanner;

public class q17 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of array");
        int a[]=new int[sc.nextInt()];
        System.out.println("enter details");
        for (int i = 0; i < a.length; i++) {
            a[i]=sc.nextInt();
        }
        a=sort(a);
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
    }
    public static int[] sort(int a[]) {
        for (int i = 0; i < a.length-1; i++) {
            for (int j = 0; j < a.length-1-i; j++) {
                boolean b=check(a, j);
                System.out.println(b);
                if(b){
                    if(a[j]>a[j+1]){
                        int t=a[j];
                        a[j]=a[j+1];
                        a[j+1]=t;
                    }
                }
                else{
                    continue;
                }
            }
        }
        return a;
    }
    public static boolean check(int b[], int index) {
        int cv=b[index];
        index--;
        while(index>=0){
            if(b[index]==cv) return false;
        }
        return true;
    }
}
